/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dal;

/**
 *
 * @author Camilo
 */
import model.Client;
import model.Livre;
import dl.JDBC_Connector;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ClientDAO implements IClientDAO {
    JDBC_Connector jdbc;

    public ClientDAO() {this.jdbc = JDBC_Connector.getInstance();}

    @Override
    public Client chercherClient(String usager) {
        Client clientTrouve = null;
        Connection conn = this.jdbc.getConnection();
        String sql = ClientQueryBox.CHERCHER_CLIENT_PAR_USAGER;
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, usager);
            ResultSet cursor = ps.executeQuery();
            if(cursor.next()) {
                String motDePasse = cursor.getString(2);
                clientTrouve = new Client(usager, motDePasse );
            }
            
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        
        return clientTrouve;
    }

    @Override
    public void creerClient(Client client) {
        Connection conn = this.jdbc.getConnection();
        String sql = ClientQueryBox.CREER_CLIENT;
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, client.getUsager());
            ps.setString(2, client.getMotDePasse());
            ps.setString(3, client.getNom());
            ps.setString(4, client.getPrenom());
            ps.setString(5, client.getAdresse());
            ps.setString(6, client.getEmail());
            ps.setString(7, client.getTelephone());
            ps.executeUpdate();
            
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }
}

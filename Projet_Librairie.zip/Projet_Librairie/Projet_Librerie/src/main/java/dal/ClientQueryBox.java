/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dal;

/**
 *
 * @author Camilo
 */
public class ClientQueryBox {
    public static final String CREER_CLIENT = "insert into Client values(usager, mot_de_passe, nom, prenom, email, adresse, telephone) VALUES (?,?,?,?,?,?,?)";
public static final String CHERCHER_CLIENT_PAR_USAGER = "select * from Client where usager=?";
}
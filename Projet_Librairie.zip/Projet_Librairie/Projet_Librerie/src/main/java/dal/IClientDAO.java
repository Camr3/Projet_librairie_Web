/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dal;

/**
 *
 * @author Camilo
 */
import model.Client;

public interface IClientDAO {
    public Client chercherClient(String usager);
    public void creerClient(Client client);



}


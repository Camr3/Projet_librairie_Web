/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controle;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Vector;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.Livre;

/**
 *
 * @author Camilo
 */
public class Magasin extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    //on récupère la session de la requête
    HttpSession session = request.getSession();
    if (session == null) {
      response.sendRedirect("http://localhost:82/error.html");
    }
    int id = Integer.parseInt(request.getParameter("id"));
    String titre =request.getParameter("titre");
        String auteur =request.getParameter("auteur");
        String genre = request.getParameter("genre");
        String langue =request.getParameter("langue");
        Double prix = Double.parseDouble(request.getParameter("prix"));
    
    Vector panier = (Vector)session.getAttribute("panier");
    Livre aLivre = new Livre(id,titre, auteur, genre, prix, langue);
    aLivre.setQte(1);
    
     
        boolean match=false;
       
       
        if (panier==null) {           
          panier = new Vector();
          panier.addElement(aLivre);
   
        } else { 
            
          for (int i=0; i< panier.size(); i++) {
            
            //on récupère l'item à la position i
            Livre livre = (Livre) panier.elementAt(i);
            
            // si on trouve l'item dans le panier
            if (livre.getTitre().equals(aLivre.getTitre())) {

               //on va modifier la quantité en lui ajoutantant la
               // nouvelle quantité
              livre.setQte(livre.getQte()+aLivre.getQte());

              //on replace l'item dans le panier
              panier.setElementAt(livre,i);

              //on active la variable qui montre qu'on a trouvé l'item
              //dans le panier
              match = true;
            } //end of if name matches
          } // end of for

          //si match est à false, donc item non déjà dans le panier,
          //on va devoir l'ajouter
          if (!match)
              //on ajoute l'item au panier
            panier.addElement(aLivre);
        }
        
        session.setAttribute("panier", panier);
        RequestDispatcher dispatcher = request.getRequestDispatcher("Bienvenue.jsp");
        dispatcher.forward(request, response);
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Services;

/**
 *
 * @author Camilo
 */
import dal.IClientDAO;

import model.Client;

public class ClientService {
    IClientDAO clientDAO;

    public ClientService(IClientDAO clientDAO) {
        this.clientDAO = clientDAO;
    }

    public void ajouterClient(Client client){
        this.clientDAO.creerClient(client);
    }

    public Client chercherClient(String usager){
      Client client = this.clientDAO.chercherClient(usager);
    return client;
    }
}

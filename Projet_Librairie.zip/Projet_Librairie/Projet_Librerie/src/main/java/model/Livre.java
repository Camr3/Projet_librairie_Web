/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author Camilo
 */
 public class Livre {
        private int id;
        private String titre;
        private String auteur;
        private String genre;
        private double prix;
        private String langue;
        private int qte;

        public Livre(){}

        public Livre(int id,String titre, String auteur, String genre, double prix, String langue ){
            this.id = id;
            this.titre = titre;
            this.auteur = auteur;
            this.genre = genre;
            this.prix = prix;
            this.langue = langue;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getTitre(){
            return titre;
        }

        public void setTitre(String titre){
            this.titre = titre;
        }

        public String getAuteur(){
            return auteur;
        }

        public void setAuteur(String auteur){
            this.auteur = auteur;
        }

        public String getGenre(){
            return genre;
        }

        public void setGenre(String genre){
            this.genre = genre;
        }

        public double getPrix(){
            return prix;
        }

        public void setPrix(double prix){
            this.prix  =  prix;

        }

        public String getLangue(){
            return langue;
        }

        public void setLangue(String langue){
            this.langue = langue;
        }
        
        public void setQte(int qte){
        this.qte = qte;
                }
        
        public int getQte(){
        return qte;
        }
        
        
       

        @Override
        public String toString() {
            return "Livre{" +
                    "id=" + id +
                    ", Titre='" + titre + '\'' +
                    ", Auteur='" + auteur + '\'' +
                    ", Genre='" + genre + '\'' +
                    ", prix=" + prix + '\'' +
                    ", langue='" + langue +
                    '}';
        }

    }
